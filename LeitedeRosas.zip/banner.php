<div class="Banner">
			<div class="picture-slides-container">
				<div class="picture-slides-fade-container">
					<a class="picture-slides-image-link">
						<span class="picture-slides-image-load-fail">The image failed to load:</span>
						<img class="picture-slides-image" src="recursos/images/image-2.jpg" alt="This is picture 1" />
					</a>
				</div>		
				<div class="navigation-controls">
					<a href="index.html" class="picture-slides-previous-image"><img src="recursos/images/arrowleft.png" alt="" /></a>				
					<a href="index.html" class="picture-slides-next-image"><img src="recursos/images/arrowright.png" alt="" /></a>				
				</div>		
				<ul class="picture-slides-thumbnails">
					<li><a href="recursos/images/image-2.jpg"><span></span><img src="recursos/images/thumbnails/thumb-2.jpg" alt="" /></a></li>
					<li><a href="recursos/images/image-1.jpg"><span></span><img src="recursos/images/thumbnails/thumb-1.jpg" alt="" /></a></li>
					<li><a href="recursos/images/image-3.jpg"><span></span><img src="recursos/images/thumbnails/thumb-3.jpg" alt="" /></a></li>
					<li><a href="recursos/images/image-4.jpg"><span></span><img src="recursos/images/thumbnails/thumb-4.jpg" alt="" /></a></li>				
				</ul>		
			</div>
		</div> 