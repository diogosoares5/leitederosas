<?php
$conexao = mysql_connect("localhost","root","")
or die("Cofiguração de Banco de Dados Errada");
$db = mysql_select_db("LeitedeRosas",$conexao)
or die("Cofiguração de Banco de Dados Errada");

function redirecionar($url, $tempo) 
{ 
    $url = str_replace('&', '&', $url); 
         
    if($tempo > 0) 
    { 
        header("Refresh: $tempo; URL=$url"); 
    } 
    else 
    { 
        @ob_flush();
        @ob_end_clean();
        header("Location: $url"); 
        
    } 
} 
$nome = $_POST['nomes'];
$email = $_POST['emails'];

$sql = mysql_query("INSERT INTO  newsletteremails (nome_newsletter  ,email_newsletter) VALUES ('$nome',  '$email')");

if ($sql == 1 ) {
echo "bem vindo $nome , seu cadastro foi realizado com sucesso";
redirecionar('index.php', 1);
}
elseif ($sql == 0 )
{
echo "não foi bem sucedido";
}

?>