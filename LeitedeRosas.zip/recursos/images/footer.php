		<div id="Footer">
			
			<div class="Area1">
				<div class="Wrap-inner">	
					<!-- MENU -->
					<?php
                    $menu_name = 'Menu Rodape';
                    
                    $menu = wp_get_nav_menu_object( $menu_name );
                    
                    $menu_items = wp_get_nav_menu_items($menu->term_id);
                    
                    $menu_list = '<ul class="list">';
                    
                    if($menu_items) :
                    
                        foreach ( $menu_items as $key => $menu_item ) {
                            $title = $menu_item->title;
                            $url = $menu_item->url;
                            $has_sub = false;
                            
                            # Verifica se existe algum menu filho
                            foreach ( $menu_items as $key => $submenu_item ) {
                                if($submenu_item->menu_item_parent ==$menu_item->ID)
                                {
                                    $has_sub = true;	
                                }
                            }
                            
                            # Se existir filhos primeira condição, senão executa a segunda
                            if($has_sub)
                            {
                                $menu_list .= '<li class="sub"><a href="' . $url . '"><span>' . $title . '</span></a>';
                                $menu_list .= '<ul class="children">';
                                
                                foreach ( $menu_items as $key => $submenu_item ) {
                                    if($submenu_item->menu_item_parent ==$menu_item->ID)
                                    {
                                        $menu_list .= '<li><a href="'.$submenu_item->url.'">'.$submenu_item->title.'</a></li>';	
                                    }
                                    
                                }
                                
                                $menu_list .= '</ul>';
                                $menu_list .= '</li>';	
                            } else {
                                # Exibe o menu caso não tenha pai
                                if($menu_item->menu_item_parent==0)
                                {
                                    $menu_list .= '<li><a href="' . $url . '"><span>' . $title . '</span></a></li>';	
                                }
                            }
                        
                        }
                    endif;
                    
                    $menu_list .= '</ul>';
                    
                    echo $menu_list;
                        
                    // $menu_list now ready to output
                    ?>  
                    <!-- FIM MENU -->
                    <div class="Box-Newsletter">
					<div class="Newsletter">
						<h3><img src="<?php bloginfo('template_url'); ?>/img/image-tit-newsletter.png" alt="" title="" /></h3>
                        <input id="nome_newsletter" class="inpt01 bdr2" type="text" text="Nome" onfocus="javascript:if (this.value == 'Nome') {this.value = '';}" onblur="javascript:if (this.value == '') {this.value = 'Nome';}" value="Nome" name="Nome" />
						<input id="email_newsletter" class="inpt02 bdr2" type="text" text="E-mail" onfocus="javascript:if (this.value == 'E-mail') {this.value = '';}" onblur="javascript:if (this.value == '') {this.value = 'E-mail';}" value="E-mail" name="E-mail" />
						<input class="send"type="submit" value="ok" name="" onclick="cadastraUsuario();" />
					</div>
                    <div class="response_news Newsletter">
                        <h3>
                        	<img title="" alt="" src="<?php bloginfo('template_url'); ?>/img/image-tit-newsletter.png">
                            </h3>
                        <div class="response"></div>
                    </div>
                    </div>
                    
					<div class="link">
                        <a href="https://www.facebook.com/outershoes" target="_blank"><img src="<?php bloginfo('template_url'); ?>/img/image-ico-face.png" alt="" title="" /></a>
                        <a href="http://pinterest.com/outershoes/" target="_blank"><img src="<?php bloginfo('template_url'); ?>/img/image-ico-pinnest.png" alt="" title="" /></a>
                        <?php $pageBlog = get_page_by_title( 'Jardim Urbano' ); ?>
						<a href="<?php echo get_permalink($pageBlog->ID); ?>"><img src="<?php bloginfo('template_url'); ?>/img/image-ico-blog.png" alt="" title="" /></a>
					</div>	
				</div>
			</div>
			<div class="Area2">
				<div class="Wrap-inner">
					<img src="<?php bloginfo('template_url'); ?>/img/image-ico-footer-logo.png" alt="" title="" />
					<span>© 2005-2012. Todos os direitos reservados.</span>
					<span class="dizain"><a href="http://www.dizain.com.br" target="_blank">Desenvolvido por DIZ’AIN</a></span>
				</div>
			</div>
		</div>	